package com.greatlearning.employeemanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greatlearning.employeemanagement.entity.Employee;
import com.greatlearning.employeemanagement.service.EmployeeServiceImpl;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeServiceImpl employeeServiceImpl;

	@GetMapping("/list")
	public List<Employee> findAll() {
		return employeeServiceImpl.findAll();
	}

	@GetMapping("/sortedList")
	public List<Employee> getEmployeeSortedByName(String direction) {
		return employeeServiceImpl.getEmployeeSortedByName(direction);
	}

	@GetMapping("/findById")
	public Employee findById(long id) {
		Employee emp = new Employee();
		try {
			emp = employeeServiceImpl.findById(id);
		} catch (Exception e) {
			System.out.println(emp);
		}
		return emp;
	}

	@GetMapping("/findByName")
	public List<Employee> findByName(String firstName) {
		return employeeServiceImpl.findByName(firstName);
	}

	@PostMapping("/addEmployee")
	public Employee addEmployee(String firstName, String lastName, String email) {
		Employee employee = new Employee(firstName, lastName, email);
		employeeServiceImpl.save(employee);
		return employee;
	}

	@PutMapping("/updateEmployee")
	public Employee updateEmployee(Employee employee) {
		employeeServiceImpl.updateEmployee(employee);
		return employee;
	}

	@DeleteMapping("/deleteEmployeeByid")
	public String deleteEmployeeByid(int id) {
		employeeServiceImpl.deleteById(id);
		return "Employee Deleted";
	}
}
