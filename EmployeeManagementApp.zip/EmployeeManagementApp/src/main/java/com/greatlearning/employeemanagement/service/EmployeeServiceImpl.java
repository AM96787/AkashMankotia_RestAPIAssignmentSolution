package com.greatlearning.employeemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.greatlearning.employeemanagement.entity.Employee;
import com.greatlearning.employeemanagement.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	@Transactional
	public List<Employee> findAll() {
		List<Employee> employees = employeeRepository.findAll();
		return employees;
	}

	@Override
	@Transactional
	public List<Employee> getEmployeeSortedByName(String direction) {
		if (direction.equals("ASC"))
			return employeeRepository.findAll(Sort.by(Direction.ASC, "firstName"));
		else if (direction.equals("DESC"))
			return employeeRepository.findAll(Sort.by(Direction.DESC, "firstName"));
		return null;
	}

	@Override
	@Transactional
	public Employee findById(long theId) {
		return employeeRepository.findById(theId).get();
	}

	@Override
	@Transactional
	public void save(Employee theEmployee) {
		employeeRepository.saveAndFlush(theEmployee);
	}

	@Override
	@Transactional
	public void updateEmployee(Employee employee) {
		boolean exist = employeeRepository.existsById(employee.getId());
		if (exist) {
			employeeRepository.saveAndFlush(employee);
		} else {
			throw new RuntimeException("There is no employee with id " + employee.getId());
		}
	}

	@Override
	public void deleteById(long theId) {
		employeeRepository.deleteById(theId);
		;
	}

	@Override
	public List<Employee> findByName(String firstName) {
		Employee emp = new Employee();
		emp.setFirstName(firstName);
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withMatcher("firstName", ExampleMatcher.GenericPropertyMatchers.exact())
				.withIgnorePaths("id", "lastName", "email");
		Example<Employee> example = Example.of(emp, exampleMatcher);
		return employeeRepository.findAll(example, Sort.by("firstName"));
	}

}
